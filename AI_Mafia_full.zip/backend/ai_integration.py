import os
import random
import httpx
from typing import Optional, List, Dict, Any
from pydantic import BaseModel


class AIPlayer:
    def __init__(self, player_id: str, player_name: str, role: str, is_alive: bool = True):
        self.id = player_id
        self.name = player_name
        self.role = role
        self.is_alive = is_alive
        self.conversation_history: List[Dict[str, str]] = []
        self.known_info: List[Dict[str, Any]] = []
        self.voting_strategy: Optional[str] = None


class YandexAIIntegration:
    def __init__(self, api_key: Optional[str] = None, folder_id: Optional[str] = None):
        self.api_key = api_key or os.getenv("YANDEX_API_KEY", "")
        self.folder_id = folder_id or os.getenv("YANDEX_FOLDER_ID", "")
        self.base_url = "https://ai.api.cloud.yandex.net/v1"
        self.project_id = folder_id
        self.enabled = bool(self.api_key and self.folder_id and len(self.api_key) > 10)
        print(f"=== Yandex AI initialized: enabled={self.enabled}, key={self.api_key[:10] if self.api_key else 'None'}..., folder={self.folder_id}")

    async def generate_response(self, ai_player: AIPlayer, game_state: Dict[str, Any]) -> Optional[str]:
        print(f"=== generate_response called: enabled={self.enabled}")
        
        if not self.enabled:
            return self._generate_fallback_response(ai_player, game_state)
        
        role = ai_player.role
        name = ai_player.name
        players_list = [p['name'] for p in game_state.get('players', []) if p.get('is_alive')]
        
        if role == "mafia":
            instruction = 'Ты МАФИЯ! Притворяйся мирным. Никогда НЕ раскрывай свою роль. Скажи 1-2 предложения в чате.'
        elif role == "sheriff":
            instruction = 'Ты ШЕРИФ! Помоги мирным найти мафию. Можешь проверять ночью. Скажи 1-2 предложения.'
        elif role == "doctor":
            instruction = 'Ты ДОКТОР! Защищай игроков ночью. Скажи 1-2 предложения в чате.'
        else:
            instruction = 'Ты МИРНЫЙ! Найди мафию голосованием. Скажи 1-2 предложения.'
        
        user_message = f"""Состояние игры: День {game_state.get('day_number', 1)}, {game_state.get('phase', 'day')}
Игроки: {', '.join(players_list)}

{instruction}

Твоё имя: {name}

Ответь 1-2 предложениями в роли {role}:"""
        
        print(f"=== AI {name} ({role}): {instruction[:40]}")
        
        try:
            import openai
            client = openai.OpenAI(
                api_key=self.api_key,
                base_url="https://ai.api.cloud.yandex.net/v1",
                project=self.project_id
            )
            
            response = client.responses.create(
                prompt={"id": "fvt02bov3oc68rolfcbm"},
                input=user_message,
            )
            
            result = response.output_text
            print(f"Yandex response: {result[:80] if result else 'empty'}")
            return result if result else self._generate_fallback_response(ai_player, game_state)
            
        except Exception as e:
            print(f"Yandex exception: {e}")
            return self._generate_fallback_response(ai_player, game_state)

    def _generate_fallback_response(self, ai_player: AIPlayer, game_state: Dict[str, Any]) -> str:
        role = ai_player.role
        responses = {
            "mafia": ["Я мирный, давайте голосовать!", "Доверяю всем здесь", "Нужно кого-то исключить"],
            "sheriff": ["Собираю информацию", "Нужно быть осторожнее", "Анализирую ситуацию"],
            "doctor": ["Нужно защитить всех", "Работаю на благо города", "Слежу за безопасностью"],
            "villager": ["Давайте обсудим", "Кого подозреваем?", "Слушаю мнения"],
        }
        return random.choice(responses.get(role, responses["villager"]))

    def generate_vote_target(self, ai_player: AIPlayer, game_state: Dict[str, Any]) -> Optional[str]:
        alive_players = [p for p in game_state.get("players", []) if p.get("is_alive") and p["id"] != ai_player.id]
        if not alive_players:
            return None
        return random.choice(alive_players)["id"]


yandex_ai = YandexAIIntegration(
    api_key=os.getenv("YANDEX_API_KEY", ""),
    folder_id=os.getenv("YANDEX_FOLDER_ID", "")
)