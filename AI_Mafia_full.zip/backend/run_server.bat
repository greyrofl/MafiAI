@echo off
cd /d %~dp0
start "" python -m uvicorn main:app --port 8000