import uuid
import random
import os
from typing import Optional, List, Dict, Any
from sqlalchemy.orm import Session
from datetime import datetime
from dataclasses import dataclass, field

from database import RoomDB, PlayerDB, MessageDB, VoteDB, NeuralMemoryDB, GameSession
from ai_integration import AIPlayer, yandex_ai, YandexAIIntegration


@dataclass
class NightAction:
    player_id: int
    action_type: str  # "kill", "check", "save", "skip"
    target_id: Optional[int] = None


@dataclass 
class NightResult:
    killed: Optional[int] = None
    saved: Optional[int] = None
    checked: Optional[int] = None
    checked_role: Optional[str] = None


class GameEngine:
    def __init__(self):
        self.ai_players: Dict[int, AIPlayer] = {}
        self.night_actions: Dict[int, List[NightAction]] = {}
        self.night_results: Dict[int, NightResult] = {}
        self.last_night_result: Optional[NightResult] = None
        self.sheriff_checks: Dict[int, Dict[int, str]] = {}
        self.doctor_saves: Dict[int, int] = {}
        self.yandex = YandexAIIntegration(
            api_key=os.getenv("YANDEX_API_KEY", ""),
            folder_id=os.getenv("YANDEX_FOLDER_ID", "")
        )

    def get_room(self, db: Session, room_id: int) -> Optional[RoomDB]:
        return db.query(RoomDB).filter(RoomDB.id == room_id).first()

    def get_online_rooms(self, db: Session) -> List[RoomDB]:
        return db.query(RoomDB).filter(RoomDB.is_public == True, RoomDB.phase == "lobby").all()

    def start_game(self, db: Session, room_id: int, host_id: int) -> Optional[RoomDB]:
        room = self.get_room(db, room_id)
        if not room or room.host_id != host_id:
            return None
        
        needed_ai = room.ai_count - len([p for p in room.players if p.is_ai])
        if needed_ai > 0:
            ai_names = ["Alex", "Boris", "Charlie", "Diana", "Edward", "Fiona", "George", "Helen"]
            existing_ai = len([p for p in room.players if p.is_ai])
            for i in range(needed_ai):
                if existing_ai + i >= len(ai_names):
                    break
                player = PlayerDB(
                    room_id=room_id,
                    user_id=None,
                    name=ai_names[existing_ai + i],
                    is_ai=True,
                    is_alive=True
                )
                db.add(player)
            db.commit()
        
        roles = self._assign_roles(len(room.players))
        
        for i, player in enumerate(room.players):
            player.role = roles[i]
            player.is_alive = True
        
        room.phase = "day"
        room.day_number = 1
        db.commit()
        
        for player in room.players:
            if player.is_ai:
                self.ai_players[player.id] = AIPlayer(
                    player_id=str(player.id),
                    player_name=player.name,
                    role=player.role
                )
        
        self.night_actions[room_id] = []
        self.night_results[room_id] = NightResult()
        
        self._add_memory(db, room, "game_started", f"Game started with {len(room.players)} players: {roles.count('mafia')} mafia, {roles.count('sheriff')} sheriff, {roles.count('doctor')} doctor, {roles.count('villager')} villagers", [])
        
        return room

    def _assign_roles(self, player_count: int) -> List[str]:
        roles = ["villager"] * player_count
        mafia_count = max(1, player_count // 4)
        
        indices = list(range(player_count))
        random.shuffle(indices)
        
        for i in range(mafia_count):
            roles[indices[i]] = "mafia"
        
        if player_count >= 6:
            sheriff_idx = indices[mafia_count] if mafia_count < player_count else indices[0]
            roles[sheriff_idx] = "sheriff"
        
        if player_count >= 8:
            doctor_idx = indices[mafia_count + 1] if mafia_count + 1 < player_count else indices[(mafia_count + 1) % player_count]
            roles[doctor_idx] = "doctor"
        
        return roles

    def add_message(self, db: Session, room_id: int, player_id: int, text: str) -> Optional[MessageDB]:
        room = self.get_room(db, room_id)
        if not room:
            return None
        
        player = next((p for p in room.players if p.id == player_id), None)
        if not player:
            return None
        
        message = MessageDB(
            room_id=room_id,
            player_id=player.user_id,
            player_name=player.name,
            text=text,
            is_ai=player.is_ai
        )
        db.add(message)
        db.commit()
        db.refresh(message)
        
        if player.is_ai and player.id in self.ai_players:
            messages = [{"player_name": m.player_name, "text": m.text} for m in room.messages[-20:]]
            game_state = self._build_game_state(room)
            self.ai_players[player.id].update_context(messages, game_state)
        
        return message

    def get_messages(self, db: Session, room_id: int, after_id: Optional[str] = None) -> List[MessageDB]:
        room = self.get_room(db, room_id)
        if not room:
            return []
        
        query = db.query(MessageDB).filter(MessageDB.room_id == room_id)
        if after_id:
            try:
                after_msg = db.query(MessageDB).filter(MessageDB.id == int(after_id)).first()
                if after_msg:
                    query = query.filter(MessageDB.timestamp > after_msg.timestamp)
            except:
                pass
        
        return query.order_by(MessageDB.timestamp).all()

    def get_memory(self, db: Session, room_id: int) -> List[NeuralMemoryDB]:
        return db.query(NeuralMemoryDB).filter(NeuralMemoryDB.room_id == room_id).order_by(NeuralMemoryDB.timestamp).all()

    def vote(self, db: Session, room_id: int, player_id: int, target_id: int) -> Optional[VoteDB]:
        room = self.get_room(db, room_id)
        if not room:
            return None
        
        player = next((p for p in room.players if p.id == player_id), None)
        target = next((p for p in room.players if p.id == target_id), None)
        if not player or not target:
            return None
        
        existing = db.query(VoteDB).filter(
            VoteDB.room_id == room_id,
            VoteDB.player_id == player_id,
            VoteDB.day_number == room.day_number
        ).first()
        if existing:
            existing.target_id = target_id
        else:
            existing = VoteDB(
                room_id=room_id,
                player_id=player_id,
                target_id=target_id,
                day_number=room.day_number
            )
            db.add(existing)
        
        db.commit()
        db.refresh(existing)
        
        self._add_memory(db, room, "vote", f"{player.name} voted for {target.name}", [str(player_id), str(target_id)])
        
        return existing

    def submit_night_action(self, db: Session, room_id: int, player_id: int, action_type: str, target_id: Optional[int] = None) -> bool:
        room = self.get_room(db, room_id)
        if not room or room.phase != "night":
            return False
        
        player = next((p for p in room.players if p.id == player_id), None)
        if not player or not player.is_alive:
            return False
        
        if room_id not in self.night_actions:
            self.night_actions[room_id] = []
        
        action = NightAction(player_id=player_id, action_type=action_type, target_id=target_id)
        self.night_actions[room_id] = [a for a in self.night_actions[room_id] if a.player_id != player_id]
        self.night_actions[room_id].append(action)
        
        if action_type == "check" and target_id:
            self.sheriff_checks[player_id] = {target_id: "villager"}
        
        if action_type == "save" and target_id:
            self.doctor_saves[player_id] = target_id
        
        return True

    def get_night_result(self, room_id: int) -> Optional[NightResult]:
        return self.last_night_result

    def change_phase(self, db: Session, room_id: int, host_id: int) -> Optional[RoomDB]:
        room = self.get_room(db, room_id)
        if not room:
            return None
        
        if host_id != 0 and room.host_id != host_id:
            return None
        
        room_id = int(room_id)
        
        if room.phase == "day":
            room.phase = "night"
            self._process_ai_night_actions_simple(db, room)
            self._add_memory(db, room, "night_start", f"Night {room.day_number} started", [])
            
            if room_id not in self.night_actions:
                self.night_actions[room_id] = []
            if room_id not in self.night_results:
                self.night_results[room_id] = NightResult()
                
        elif room.phase == "night":
            result = self._process_night(db, room)
            self.last_night_result = result
            
            self._process_day_votes(db, room)
            room.phase = "day"
            room.day_number += 1
            
            if self._check_win_condition(room):
                room.phase = "game_over"
                self._record_game_sessions(db, room)
                self._add_memory(db, room, "game_over", f"Winner: {self._get_winner(room)}", [])
            else:
                self._add_memory(db, room, "day_start", f"Day {room.day_number} started - {self._format_night_result(result)}", [])
            
            self.night_actions[room_id] = []
            self.night_results[room_id] = NightResult()
        
        db.commit()
        return room
    
    def _process_ai_night_actions_simple(self, db: Session, room: RoomDB) -> None:
        alive_players = [p for p in room.players if p.is_alive]
        
        mafia_members = [p for p in alive_players if p.role == "mafia"]
        if mafia_members:
            villagers = [p for p in alive_players if p.role != "mafia"]
            if villagers:
                target = random.choice(villagers)
                self.night_actions[room.id].append(NightAction(
                    player_id=mafia_members[0].id,
                    action_type="kill",
                    target_id=target.id
                ))
        
        doctors = [p for p in alive_players if p.role == "doctor"]
        if doctors and alive_players:
            save_target = random.choice(alive_players)
            self.night_actions[room.id].append(NightAction(
                player_id=doctors[0].id,
                action_type="save",
                target_id=save_target.id
            ))
        
        sheriffs = [p for p in alive_players if p.role == "sheriff"]
        if sheriffs and alive_players:
            check_target = random.choice(alive_players)
            self.night_actions[room.id].append(NightAction(
                player_id=sheriffs[0].id,
                action_type="check",
                target_id=check_target.id
            ))

    def _format_night_result(self, result: NightResult) -> str:
        parts = []
        if result.killed and result.saved:
            parts.append(f"{result.killed} was killed but saved by doctor")
        elif result.killed:
            parts.append(f"{result.killed} was killed by mafia")
        if result.checked:
            parts.append(f"Sheriff checked: {result.checked_role}")
        return ", ".join(parts) if parts else "peaceful night"

    def _process_night(self, db: Session, room: RoomDB) -> NightResult:
        result = NightResult()
        
        if room.id not in self.night_actions:
            self.night_actions[room.id] = []
        
        mafia_kills = [a for a in self.night_actions[room.id] if a.action_type == "kill" and a.target_id]
        if mafia_kills:
            target_counts: Dict[int, int] = {}
            for kill in mafia_kills:
                target_counts[kill.target_id] = target_counts.get(kill.target_id, 0) + 1
            
            if target_counts:
                result.killed = max(target_counts, key=target_counts.get)
        
        doctor_saves = [a for a in self.night_actions[room.id] if a.action_type == "save" and a.target_id]
        if doctor_saves:
            result.saved = doctor_saves[-1].target_id
            self.doctor_saves[room.id] = result.saved
        
        if result.killed and result.killed == result.saved:
            result.killed = None
            self._add_memory(db, room, "doctor_save", f"Doctor saved a player", [str(result.saved)])
        elif result.killed:
            killed_player = next((p for p in room.players if p.id == result.killed), None)
            if killed_player:
                killed_player.is_alive = False
                self._add_memory(db, room, "mafia_kill", 
                              f"{killed_player.name} was killed by mafia (role: {killed_player.role})", 
                              [str(result.killed)])
                if killed_player.id in self.ai_players:
                    del self.ai_players[killed_player.id]
        
        sheriff_checks = [a for a in self.night_actions[room.id] if a.action_type == "check" and a.target_id]
        if sheriff_checks:
            check_target = sheriff_checks[0].target_id
            checked_player = next((p for p in room.players if p.id == check_target), None)
            if checked_player:
                result.checked = check_target
                result.checked_role = checked_player.role if checked_player.is_alive else "dead"
                self._add_memory(db, room, "sheriff_check", 
                              f"Sheriff checked {checked_player.name}: {result.checked_role}", 
                              [str(check_target)])
        
        db.commit()
        return result

    async def _process_ai_night_actions(self, db: Session, room: RoomDB) -> None:
        for player in room.players:
            if not player.is_ai or not player.is_alive:
                continue
            
            if player.role == "mafia":
                game_state = self._build_game_state(room)
                alive_villagers = [p for p in room.players if p.is_alive and p.role != "mafia"]
                if alive_villagers:
                    target = random.choice(alive_villagers)
                    self.submit_night_action(db, room.id, player.id, "kill", target.id)
            
            elif player.role == "sheriff":
                game_state = self._build_game_state(room)
                alive_suspicious = [p for p in room.players if p.is_alive and p.role == "mafia"]
                if alive_suspicious:
                    target = random.choice(alive_suspicious)
                    self.submit_night_action(db, room.id, player.id, "check", target.id)
            
            elif player.role == "doctor":
                game_state = self._build_game_state(room)
                alive_players = [p for p in room.players if p.is_alive and p != player]
                if alive_players:
                    target = random.choice(alive_players)
                    self.submit_night_action(db, room.id, player.id, "save", target.id)

    def _process_day_votes(self, db: Session, room: RoomDB) -> None:
        votes = db.query(VoteDB).filter(
            VoteDB.room_id == room.id,
            VoteDB.day_number == room.day_number
        ).all()
        
        if not votes:
            return
        
        vote_counts: Dict[int, int] = {}
        for vote in votes:
            vote_counts[vote.target_id] = vote_counts.get(vote.target_id, 0) + 1
        
        if vote_counts:
            eliminated_id = max(vote_counts, key=lambda k: vote_counts[k])
            eliminated = next((p for p in room.players if p.id == eliminated_id), None)
            if eliminated and vote_counts[eliminated_id] > len(votes) // 2:
                eliminated.is_alive = False
                self._add_memory(db, room, "elimination", 
                               f"{eliminated.name} was voted out (role: {eliminated.role})", 
                               [str(eliminated_id)])
                
                if eliminated.id in self.ai_players:
                    del self.ai_players[eliminated.id]
        
        db.query(VoteDB).filter(VoteDB.room_id == room.id).delete()
        db.commit()

    def _check_win_condition(self, room: RoomDB) -> bool:
        alive = [p for p in room.players if p.is_alive]
        alive_mafia = [p for p in alive if p.role == "mafia"]
        alive_villagers = [p for p in alive if p.role != "mafia"]
        
        return len(alive_mafia) == 0 or len(alive_mafia) >= len(alive_villagers)

    def _get_winner(self, room: RoomDB) -> str:
        if any(p.is_alive and p.role == "mafia" for p in room.players):
            return "Mafia"
        return "Villagers"

    def _build_game_state(self, room: RoomDB) -> Dict[str, Any]:
        return {
            "room_id": room.id,
            "phase": room.phase,
            "day_number": room.day_number,
            "players": [
                {
                    "id": str(p.id),
                    "name": p.name,
                    "role": p.role if p.is_alive or p.role else None,
                    "is_alive": p.is_alive,
                    "is_ai": p.is_ai
                }
                for p in room.players
            ]
        }

    def _add_memory(self, db: Session, room: RoomDB, event_type: str, description: str, affected_players: List[str]) -> None:
        memory = NeuralMemoryDB(
            room_id=room.id,
            event_type=event_type,
            description=description,
            affected_players=affected_players,
            day_number=room.day_number
        )
        db.add(memory)
        db.commit()

    def _record_game_sessions(self, db: Session, room: RoomDB) -> None:
        winner = self._get_winner(room)
        for player in room.players:
            if player.user_id:
                is_winner = (player.role == "mafia" and winner == "Mafia") or \
                           (player.role != "mafia" and winner == "Villagers")
                session = GameSession(
                    user_id=player.user_id,
                    room_id=room.id,
                    role=player.role,
                    won=is_winner
                )
                db.add(session)
        db.commit()

    async def get_ai_response(self, db: Session, room_id: int, ai_player_id: int) -> Optional[str]:
        room = self.get_room(db, room_id)
        if not room:
            return None
        
        ai_player = self.ai_players.get(ai_player_id)
        if not ai_player:
            return None
        
        game_state = self._build_game_state(room)
        response = await self.yandex.generate_response(ai_player, game_state)
        
        if response:
            self.add_message(db, room_id, ai_player_id, response)
        
        return response


    async def generate_ai_message(self, db: Session, room_id: int, ai_player_id: int) -> Optional[str]:
        room = self.get_room(db, room_id)
        if not room:
            print(f"Room {room_id} not found in generate_ai_message")
            return None
        
        ai_player = self.ai_players.get(ai_player_id)
        if not ai_player:
            print(f"AI player {ai_player_id} not found in ai_players dict. Available: {list(self.ai_players.keys())}")
            return None
        
        print(f"Generating response for AI player {ai_player.player_name} with role {ai_player.role}")
        game_state = self._build_game_state(room)
        response = await self.yandex.generate_response(ai_player, game_state)
        
        if not response:
            print("No response from Yandex API")
            return None
        
        self.add_message(db, room_id, ai_player_id, response)
        print(f"AI {ai_player.player_name} said: {response}")
        
        return response


game_engine = GameEngine()