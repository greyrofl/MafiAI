@echo off
cd /d %~dp0
set YANDEX_API_KEY=AQVNxXkU-KhzwWq4Q_9KkIiqO0xjEBu_RYqSoJp2
set YANDEX_FOLDER_ID=aje5f4afha3jo5lbggvv
python -m uvicorn main:app --host 127.0.0.1 --port 8000