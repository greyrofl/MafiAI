from fastapi import FastAPI
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from typing import Optional
from auth import decode_token
from database import get_db, User

app = FastAPI()
bearer_scheme = HTTPBearer(auto_error=False)

def get_optional_user(
    credentials: Optional[HTTPAuthorizationCredentials] = Depends(bearer_scheme),
    db = Depends(get_db)
) -> Optional[User]:
    print(f"get_optional_user called with credentials: {credentials}")
    if not credentials:
        print("No credentials - returning None")
        return None
    token_data = decode_token(credentials.credentials)
    if not token_data:
        print("Invalid token - returning None")
        return None
    user = db.query(User).filter(User.id == token_data.user_id).first()
    return user

@app.post("/test")
async def test_route(user: Optional[User] = Depends(get_optional_user)):
    return {"user": user.username if user else None}