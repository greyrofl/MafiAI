from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from dotenv import load_dotenv
import os

load_dotenv()
key = os.getenv('YANDEX_API_KEY', '')
folder = os.getenv('YANDEX_FOLDER_ID', '')
print(f"[STARTUP] Loaded: API_KEY={key[:10] if key else 'NOT FOUND'}, FOLDER={folder}")

from database import init_db
from routes import router

app = FastAPI(title="AI Mafia API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(router)


@app.on_event("startup")
async def startup():
    init_db()


@app.get("/")
async def root():
    return {"message": "AI Mafia API", "status": "running"}


@app.get("/health")
async def health():
    return {"status": "healthy"}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app)