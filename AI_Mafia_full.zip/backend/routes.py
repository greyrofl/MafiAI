from fastapi import APIRouter, Depends, HTTPException, WebSocket, WebSocketDisconnect, Query
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from sqlalchemy.orm import Session
from typing import Optional
from auth import decode_token
import hashlib
import time
import uuid
import random
import asyncio

from database import get_db, User, RoomDB, PlayerDB, PendingVerification, MessageDB, VoteDB
from schemas import (
    UserRegisterRequest, VerifyCodeRequest, UserLogin, UserResponse, Token,
    RoomCreate, RoomResponse, RoomDetail, PlayerResponse,
    JoinRequest, AddAIRequest, LeaveRequest,
    MessageRequest, MessageResponse, VoteRequest, NeuralMemoryResponse
)
from auth import (
    get_password_hash, verify_password, create_access_token,
    get_current_user, get_current_user_optional,
    bearer_scheme, decode_token
)

def get_optional_user(
    credentials: Optional[HTTPAuthorizationCredentials] = Depends(bearer_scheme),
    db: Session = Depends(get_db)
) -> Optional[User]:
    if not credentials:
        return None
    token_data = decode_token(credentials.credentials)
    if not token_data:
        return None
    user = db.query(User).filter(User.id == token_data.user_id).first()
    return user
from game_engine import game_engine
from ai_integration import YandexAIIntegration, AIPlayer

API_KEY = "AQVN1cUviMDK7E3yTDD0H1b_2xhAbo2i1k5d7zKU"
FOLDER_ID = "b1gm5nsvhmd4sic0ivlv"

yandex_ai = YandexAIIntegration(api_key=API_KEY, folder_id=FOLDER_ID)

ai_players_state: dict[int, dict[int, AIPlayer]] = {}

def get_or_create_ai_player(room_id: int, player_db: PlayerDB) -> AIPlayer:
    if room_id not in ai_players_state:
        ai_players_state[room_id] = {}
    if player_db.id not in ai_players_state[room_id]:
        ai_players_state[room_id][player_db.id] = AIPlayer(
            player_id=str(player_db.id),
            player_name=player_db.name,
            role=player_db.role or "villager",
            is_alive=player_db.is_alive
        )
    return ai_players_state[room_id][player_db.id]

router = APIRouter(prefix="/api", tags=["api"])
auth_router = APIRouter(prefix="/auth", tags=["auth"])
rooms_router = APIRouter(prefix="/rooms", tags=["rooms"])

bearer_scheme = HTTPBearer(auto_error=False)

active_connections: dict[int, list[WebSocket]] = {}


async def broadcast(room_id: int, event: str, data: dict):
    if room_id in active_connections:
        disconnected = []
        for connection in active_connections[room_id]:
            try:
                await connection.send_json({"event": event, "data": data})
            except:
                disconnected.append(connection)
        for ws in disconnected:
            if ws in active_connections[room_id]:
                active_connections[room_id].remove(ws)


def generate_room_code() -> str:
    return ''.join(random.choices('ABCDEFGHIJKLMNOPQRSTUVWXYZ', k=6))


def generate_link(room_id: int) -> str:
    return hashlib.sha256(f"{room_id}|{time.time()}".encode()).hexdigest()[:16]


@auth_router.post("/register", response_model=dict)
async def register(request: UserRegisterRequest, db: Session = Depends(get_db)):
    existing = db.query(User).filter(User.email == request.email).first()
    if existing:
        raise HTTPException(status_code=400, detail="Email already registered")
    
    existing_pending = db.query(PendingVerification).filter(
        PendingVerification.email == request.email
    ).first()
    if existing_pending:
        db.delete(existing_pending)
        db.commit()
    
    code = str(random.randint(100000, 999999))
    code_hash = hashlib.sha256(code.encode()).hexdigest()
    expires_at = int(time.time()) + 600
    
    pending = PendingVerification(
        email=request.email,
        code_hash=code_hash,
        username=request.username,
        password_hash=get_password_hash(request.password),
        expires_at=datetime.fromtimestamp(expires_at)
    )
    db.add(pending)
    db.commit()
    
    from send_email import send_verification_code
    try:
        send_verification_code(request.email, code)
        print(f"Email sent to {request.email} with code {code}")
    except Exception as e:
        print(f"Email send failed: {e}")
        # Continue anyway - code still works
    
    return {"message": "Code sent to email", "email": request.email, "code": code}


@auth_router.post("/verify", response_model=UserResponse)
async def verify_code(request: VerifyCodeRequest, db: Session = Depends(get_db)):
    pending = db.query(PendingVerification).filter(
        PendingVerification.email == request.email
    ).first()
    
    if not pending:
        raise HTTPException(status_code=400, detail="Registration not started")
    
    if time.time() > pending.expires_at.timestamp():
        db.delete(pending)
        db.commit()
        raise HTTPException(status_code=400, detail="Code expired")
    
    code_hash = hashlib.sha256(request.code.encode()).hexdigest()
    if code_hash != pending.code_hash:
        raise HTTPException(status_code=400, detail="Invalid code")
    
    user = User(
        email=pending.email,
        username=pending.username,
        hashed_password=pending.password_hash,
        is_active=True,
        is_verified=True
    )
    db.add(user)
    db.delete(pending)
    db.commit()
    db.refresh(user)
    
    from send_email import send_welcome_email
    send_welcome_email(user.email, user.username)
    
    return user


@auth_router.post("/login", response_model=Token)
async def login(credentials: UserLogin, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email == credentials.email).first()
    
    if not user or not user.hashed_password:
        raise HTTPException(status_code=401, detail="Invalid credentials")
    
    if not verify_password(credentials.password, user.hashed_password):
        raise HTTPException(status_code=401, detail="Invalid credentials")
    
    access_token = create_access_token(data={"sub": str(user.id)})
    
    return Token(access_token=access_token)


@auth_router.get("/me", response_model=UserResponse)
async def get_me(current_user: User = Depends(get_current_user)):
    return current_user


@rooms_router.post("", response_model=RoomResponse)
async def create_room(req: RoomCreate, db: Session = Depends(get_db)):
    room_code = generate_room_code()
    room_key = None
    if req.room_type == "close":
        room_key = ''.join(random.choices('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', k=6))
    
    host_id = 0
    host_name = "Host"
    
    room = RoomDB(
        room_code=room_code,
        name=req.name,
        host_id=host_id,
        is_public=req.is_public,
        room_type=req.room_type,
        room_key=room_key,
        link=generate_link(0),
        max_players=req.max_players,
        ai_count=req.ai_count,
        game_type=req.game_type,
        time_limit=req.time_limit,
        phase="lobby"
    )
    db.add(room)
    db.commit()
    db.refresh(room)
    
    room.link = generate_link(room.id)
    db.commit()
    
    player = PlayerDB(
        room_id=room.id,
        user_id=host_id,
        name=host_name,
        is_host=True
    )
    db.add(player)
    db.commit()
    
    return RoomResponse(
        id=room.id,
        room_code=room.room_code,
        name=room.name,
        host_id=room.host_id,
        is_public=room.is_public,
        room_type=room.room_type,
        room_key=room.room_key,
        link=room.link,
        max_players=room.max_players,
        ai_count=room.ai_count,
        game_type=room.game_type,
        phase=room.phase,
        day_number=room.day_number,
        time_limit=room.time_limit,
        player_count=len(room.players),
        created_at=room.created_at
    )


@rooms_router.get("", response_model=list[RoomResponse])
async def list_rooms(db: Session = Depends(get_db)):
    rooms = db.query(RoomDB).filter(RoomDB.is_public == True, RoomDB.phase == "lobby").all()
    return [
        RoomResponse(
            id=r.id,
            room_code=r.room_code,
            name=r.name,
            host_id=r.host_id,
            is_public=r.is_public,
            room_type=r.room_type,
            room_key=None,
            link=r.link,
            max_players=r.max_players,
            ai_count=r.ai_count,
            game_type=r.game_type,
            phase=r.phase,
            day_number=r.day_number,
            time_limit=r.time_limit,
            player_count=len(r.players),
            created_at=r.created_at
        )
        for r in rooms
    ]


@rooms_router.get("/{room_id}", response_model=RoomDetail)
async def get_room(room_id: int, db: Session = Depends(get_db)):
    room = db.query(RoomDB).filter(RoomDB.id == room_id).first()
    if not room:
        raise HTTPException(status_code=404, detail="Room not found")
    
    from database import VoteDB
    votes = db.query(VoteDB).filter(
        VoteDB.room_id == room_id,
        VoteDB.day_number == room.day_number
    ).all()
    
    vote_counts = {}
    for v in votes:
        vote_counts[v.target_id] = vote_counts.get(v.target_id, 0) + 1
    
    return RoomDetail(
        id=room.id,
        room_code=room.room_code,
        name=room.name,
        host_id=room.host_id,
        room_type=room.room_type,
        link=room.link,
        phase=room.phase,
        day_number=room.day_number,
        time_limit=room.time_limit,
        players=[
            PlayerResponse(
                id=p.id,
                name=p.name,
                role=p.role if p.is_alive else None,
                is_ai=p.is_ai,
                is_alive=p.is_alive,
                is_host=p.is_host,
                vote_count=vote_counts.get(p.id, 0)
            )
            for p in room.players
        ],
        created_at=room.created_at
    )


@rooms_router.get("/code/{room_code}", response_model=RoomDetail)
async def get_room_by_code(room_code: str, db: Session = Depends(get_db)):
    room = db.query(RoomDB).filter(RoomDB.room_code == room_code).first()
    if not room:
        raise HTTPException(status_code=404, detail="Room not found")
    
    return RoomDetail(
        id=room.id,
        room_code=room.room_code,
        name=room.name,
        host_id=room.host_id,
        room_type=room.room_type,
        link=room.link,
        phase=room.phase,
        day_number=room.day_number,
        time_limit=room.time_limit,
        players=[
            PlayerResponse(
                id=p.id,
                name=p.name,
                role=p.role if p.is_alive else None,
                is_ai=p.is_ai,
                is_alive=p.is_alive,
                is_host=p.is_host
            )
            for p in room.players
        ],
        created_at=room.created_at
    )


@rooms_router.post("/{room_id}/join")
async def join_room(
    room_id: int,
    req: JoinRequest,
    db: Session = Depends(get_db)
):
    room = db.query(RoomDB).filter(RoomDB.id == room_id).first()
    if not room:
        raise HTTPException(status_code=404, detail="Room not found")
    
    if room.phase != "lobby":
        raise HTTPException(status_code=400, detail="Game already started")
    
    if len(room.players) >= room.max_players:
        raise HTTPException(status_code=400, detail="Room is full")
    
    room_id_int = int(room_id)
    existing = db.query(PlayerDB).filter(
        PlayerDB.room_id == room_id_int,
        PlayerDB.user_id == 0
    ).first()
    if existing:
        return {"playerId": existing.id, "roomId": room_id_int, "roomCode": room.room_code}
    
    if room.room_type == "close" and room.room_key != req.room_key:
        raise HTTPException(status_code=403, detail="Invalid room key")
    
    player_name = req.playerName or "Player"
    room_id_int = int(room_id)
    player = PlayerDB(
        room_id=room_id_int,
        user_id=0,
        name=player_name,
        is_host=False
    )
    db.add(player)
    db.commit()
    db.refresh(player)
    
    await broadcast(room_id, "player_joined", {
        "player": PlayerResponse.model_validate(player).model_dump(),
        "player_count": len(room.players) + 1
    })
    
    return {"playerId": player.id, "roomId": room_id, "roomCode": room.room_code}


@rooms_router.post("/{room_id}/demo")
async def run_demo_mode(
    room_id: int,
    db: Session = Depends(get_db)
):
    try:
        room = db.query(RoomDB).filter(RoomDB.id == room_id).first()
        if not room:
            raise HTTPException(status_code=404, detail="Room not found")
        
        db.refresh(room)
        db.refresh(room, ['players'])
        
        print(f"=== Starting DEMO for room {room_id} ===")
        
        room.phase = "day"
        room.day_number = 1
        db.commit()
        
        intro_msg = MessageDB(
            room_id=room_id,
            player_id=0,
            player_name="🎮 DEMO",
            text="🎬 НАЧИНАЕТСЯ ДEMO-ИГРА!\n\nЭто демонстрация всех возможностей игры. Все ходы будут сделаны автоматически!",
            is_ai=True
        )
        db.add(intro_msg)
        db.commit()
        
        ai_names = {
            "mafia": ["Don", "Boss", "Crit", "Luna"],
            "sheriff": ["Cop", "Detective", "Sheriff"],
            "doctor": ["Doc", "Healer", "Medic"],
            "villager": ["Villager", "Citizen", "平民"]
        }
        
        await asyncio.sleep(1)
        
        msg1 = MessageDB(
            room_id=room_id,
            player_id=0,
            player_name="🎮 DEMO",
            text="☀️ ДЕНЬ 1 - Обсуждение\n\nВсе игроки должны вычислить мафию!",
            is_ai=True
        )
        db.add(msg1)
        db.commit()
        
        alive_players = [p for p in room.players if p.is_alive]
        
        for i, player in enumerate(alive_players):
            if not player.is_ai:
                continue
            
            delay = random.uniform(0.5, 1.5)
            await asyncio.sleep(delay)
            
            statements = {
                "mafia": [
                    "Я мирный! Не верьте тем кто меня обвиняет!",
                    "Давайте голосовать против кого-то другого",
                    "У меня есть алиби на прошлую ночь",
                ],
                "sheriff": [
                    "Я слишком устал чтобы сегодня кого-то проверять",
                    "Пока никого не проверял",
                    "Нужно больше данных",
                ],
                "doctor": [
                    "Я врач! Могу кого-то спасти этой ночью",
                    "Доверяю всем в этой комнате",
                    "Давайте survive до конца!",
                ],
                "villager": [
                    "Думаю нужно голосовать",
                    "Слушаю что скажут другие",
                    "Пока не знаю кого подозревать",
                ]
            }
            
            role_key = player.role if player.role else "villager"
            text = random.choice(statements.get(role_key, statements["villager"]))
            
            msg = MessageDB(
                room_id=room_id,
                player_id=player.id,
                player_name=player.name,
                text=text,
                is_ai=True
            )
            db.add(msg)
            db.commit()
            
            print(f"[DEMO] {player.name} ({role_key}): {text}")
        
        await asyncio.sleep(1)
        
        msg_vote = MessageDB(
            room_id=room_id,
            player_id=0,
            player_name="🎮 DEMO",
            text="🗳️ ГОЛОСОВАНИЕ!",
            is_ai=True
        )
        db.add(msg_vote)
        db.commit()
        
        for player in alive_players:
            targets = [p for p in alive_players if p.id != player.id]
            if targets:
                vote_target = random.choice(targets)
                vote = VoteDB(
                    room_id=room_id,
                    player_id=player.id,
                    target_id=vote_target.id,
                    day_number=room.day_number
                )
                db.add(vote)
        
        db.commit()
        
        votes = db.query(VoteDB).filter(
            VoteDB.room_id == room_id,
            VoteDB.day_number == room.day_number
        ).all()
        
        vote_counts = {}
        for vote in votes:
            vote_counts[vote.target_id] = vote_counts.get(vote.target_id, 0) + 1
        
        max_votes = max(vote_counts.values()) if vote_counts else 0
        voted_out_ids = [pid for pid, cnt in vote_counts.items() if cnt == max_votes and max_votes > 0]
        
        if len(voted_out_ids) == 1:
            victim_id = voted_out_ids[0]
            for player in room.players:
                if player.id == victim_id:
                    player.is_alive = False
                    msg_out = MessageDB(
                        room_id=room_id,
                        player_id=0,
                        player_name="🎮 DEMO",
                        text=f"🚫 {player.name} ({player.role}) БЫЛ ВЫЧИСЛЕН!",
                        is_ai=True
                    )
                    db.add(msg_out)
        else:
            msg_none = MessageDB(
                room_id=room_id,
                player_id=0,
                player_name="🎮 DEMO",
                text="🤷 НИКТО НЕ ПОЛУЧИЛ БОЛЬШИНСТВО ГОЛОСОВ",
                is_ai=True
            )
            db.add(msg_none)
        
        db.commit()
        
        await asyncio.sleep(1)
        
        room.phase = "night"
        db.commit()
        
        msg_night = MessageDB(
            room_id=room_id,
            player_id=0,
            player_name="🎮 DEMO",
            text="🌙 НОЧЬ 1\n\nМафия выбирает жертву...",
            is_ai=True
        )
        db.add(msg_night)
        db.commit()
        
        await asyncio.sleep(1)
        
        alive_now = [p for p in room.players if p.is_alive]
        mafia_members = [p for p in alive_now if p.role == "mafia"]
        
        if mafia_members:
            victims = [p for p in alive_now if p.role != "mafia"]
            if victims:
                target = random.choice(victims)
                for player in room.players:
                    if player.id == target.id:
                        player.is_alive = False
                
                saved = random.choice(alive_now)
                if saved.id == target.id:
                    msg_kill = MessageDB(
                        room_id=room_id,
                        player_id=0,
                        player_name="🎮 DEMO",
                        text=f"💀 НОЧЬ: {target.name} был убит, но врач его СПАС!",
                        is_ai=True
                    )
                else:
                    msg_kill = MessageDB(
                        room_id=room_id,
                        player_id=0,
                        player_name="🎮 DEMO",
                        text=f"💀 НОЧЬ: {target.name} ({target.role}) БЫЛ УБИТ МАФИЕЙ!",
                        is_ai=True
                    )
                db.add(msg_kill)
        
        db.commit()
        
        await asyncio.sleep(1)
        
        room.phase = "day"
        room.day_number = 2
        db.commit()
        
        msg_day2 = MessageDB(
            room_id=room_id,
            player_id=0,
            player_name="🎮 DEMO",
            text="☀️ ДЕНЬ 2\n\nНовое утро! Кто выжил?",
            is_ai=True
        )
        db.add(msg_day2)
        db.commit()
        
        alive_final = [p for p in room.players if p.is_alive]
        mafia_left = [p for p in alive_final if p.role == "mafia"]
        
        if not mafia_left:
            room.phase = "game_over"
            msg_win = MessageDB(
                room_id=room_id,
                player_id=0,
                player_name="🎮 DEMO",
                text="🎉 ПОБЕДА МИРНЫХ!\n\nМафия уничтожена!",
                is_ai=True
            )
            db.add(msg_win)
        elif len(mafia_left) >= len(alive_final) / 2:
            room.phase = "game_over"
            msg_win = MessageDB(
                room_id=room_id,
                player_id=0,
                player_name="🎮 DEMO",
                text="💀 ПОБЕДА МАФИИ!\n\nМирные проиграли!",
                is_ai=True
            )
            db.add(msg_win)
        
        db.commit()
        
        return {"status": "demo_complete", "room_id": room_id}
        
    except Exception as e:
        print(f"DEMO error: {e}")
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e))

@rooms_router.post("/{room_id}/leave")
async def leave_room(
    room_id: int,
    req: LeaveRequest,
    db: Session = Depends(get_db)
):
    room = db.query(RoomDB).filter(RoomDB.id == room_id).first()
    if not room:
        raise HTTPException(status_code=404, detail="Room not found")
    
    player = db.query(PlayerDB).filter(PlayerDB.id == req.playerId).first()
    if not player:
        raise HTTPException(status_code=404, detail="Player not found")
    
    player_name = player.name
    db.delete(player)
    
    if room.host_id == player.user_id and room.players:
        new_host = room.players[0]
        new_host.is_host = True
        room.host_id = new_host.user_id or 0
    
    db.commit()
    
    if not room.players:
        db.delete(room)
        db.commit()
    
    await broadcast(room_id, "player_left", {
        "playerId": req.playerId,
        "playerName": player_name
    })
    
    return {"success": True}


@rooms_router.post("/{room_id}/add-ai")
async def add_ai(
    room_id: int,
    req: AddAIRequest,
    db: Session = Depends(get_db)
):
    room = db.query(RoomDB).filter(RoomDB.id == room_id).first()
    if not room:
        raise HTTPException(status_code=404, detail="Room not found")
    
    ai_names = ["Alex", "Boris", "Charlie", "Diana", "Edward", "Fiona", "George", "Helen"]
    existing_ai = len([p for p in room.players if p.is_ai])
    
    new_ai = []
    for i in range(req.ai_count):
        if existing_ai + len(new_ai) >= len(ai_names):
            break
        
        player = PlayerDB(
            room_id=room_id,
            user_id=None,
            name=ai_names[existing_ai + i],
            is_ai=True,
            is_alive=True
        )
        db.add(player)
        new_ai.append(player)
    
    db.commit()
    for p in new_ai:
        db.refresh(p)
    
    await broadcast(room_id, "ai_added", {
        "players": [PlayerResponse.model_validate(p).model_dump() for p in new_ai],
        "player_count": len(room.players)
    })
    
    return {"added": len(new_ai), "players": [p.id for p in new_ai]}


@rooms_router.post("/{room_id}/start")
async def start_game(
    room_id: int,
    db: Session = Depends(get_db)
):
    room = db.query(RoomDB).filter(RoomDB.id == room_id).first()
    if not room:
        raise HTTPException(status_code=404, detail="Room not found")
    
    if len(room.players) < 4:
        raise HTTPException(status_code=400, detail="Need at least 4 players")
    
    try:
        result = game_engine.start_game(db, room_id, 0)
        if not result:
            raise HTTPException(status_code=400, detail="Cannot start game")
        
        try:
            await broadcast(room_id, "game_started", {
                "room": RoomDetail.model_validate(result).model_dump()
            })
        except:
            pass
        
        return RoomDetail.model_validate(result)
    except Exception as e:
        print(f"Start game error: {e}")
        raise HTTPException(status_code=400, detail=f"Error: {str(e)}")


@rooms_router.get("/{room_id}/messages", response_model=list[MessageResponse])
async def get_messages(
    room_id: int,
    after: Optional[str] = Query(None),
    db: Session = Depends(get_db)
):
    messages = game_engine.get_messages(db, room_id, after)
    return [
        MessageResponse(
            id=m.id,
            player_id=m.player_id,
            player_name=m.player_name,
            text=m.text,
            is_ai=m.is_ai,
            timestamp=m.timestamp
        )
        for m in messages
    ]


@rooms_router.post("/{room_id}/messages", response_model=MessageResponse)
async def send_message(
    room_id: int,
    req: MessageRequest,
    db: Session = Depends(get_db)
):
    player = db.query(PlayerDB).filter(
        PlayerDB.room_id == room_id,
        PlayerDB.user_id == 0
    ).first()
    
    if not player:
        raise HTTPException(status_code=400, detail="Player not in room")
    
    message = game_engine.add_message(db, room_id, player.id, req.text)
    if not message:
        raise HTTPException(status_code=400, detail="Cannot send message")
    
    await broadcast(room_id, "message", {
        "message": MessageResponse.model_validate(message).model_dump()
    })
    
    return MessageResponse.model_validate(message)


@rooms_router.get("/{room_id}/memory", response_model=list[NeuralMemoryResponse])
async def get_memory(room_id: int, db: Session = Depends(get_db)):
    return game_engine.get_memory(db, room_id)


@rooms_router.post("/{room_id}/vote")
async def vote(
    room_id: int,
    req: VoteRequest,
    db: Session = Depends(get_db)
):
    room_id_int = int(room_id)
    player = db.query(PlayerDB).filter(
        PlayerDB.room_id == room_id_int,
        PlayerDB.user_id == 0
    ).first()
    
    if not player:
        raise HTTPException(status_code=400, detail="Player not in room")
    
    room = db.query(RoomDB).filter(RoomDB.id == room_id).first()
    if not room:
        raise HTTPException(status_code=404, detail="Room not found")
    
    if room.phase == "night":
        success = game_engine.submit_night_action(db, room_id, player.id, "kill", req.targetId)
        if success:
            return {"success": True, "action": "night_vote"}
    
    vote_obj = game_engine.vote(db, room_id, player.id, req.targetId)
    if not vote_obj:
        raise HTTPException(status_code=400, detail="Cannot vote")
    
    await broadcast(room_id, "vote", {
        "playerId": player.id,
        "targetId": req.targetId,
        "votes_count": len(room.votes) if room else 0
    })
    
    return {"success": True}


@rooms_router.post("/{room_id}/night-action")
async def night_action(
    room_id: int,
    req: VoteRequest,
    db: Session = Depends(get_db)
):
    player = db.query(PlayerDB).filter(
        PlayerDB.room_id == room_id,
        PlayerDB.user_id == 0
    ).first()
    
    if not player:
        raise HTTPException(status_code=400, detail="Player not in room")
    
    room = db.query(RoomDB).filter(RoomDB.id == room_id).first()
    if not room or room.phase != "night":
        raise HTTPException(status_code=400, detail="Night action only available at night")
    
    if not player.is_alive:
        raise HTTPException(status_code=400, detail="You are dead")
    
    action_types = {
        "villager": "skip",
        "mafia": "kill",
        "sheriff": "check",
        "doctor": "save"
    }
    
    action_type = action_types.get(player.role, "skip")
    success = game_engine.submit_night_action(db, room_id, player.id, action_type, req.targetId)
    
    if success:
        return {"success": True, "action": action_type, "target": req.targetId}
    
    return {"success": False, "detail": "Cannot submit action"}


@rooms_router.get("/{room_id}/night-result")
async def get_night_result(room_id: int):
    result = game_engine.get_night_result(room_id)
    if result:
        return {
            "killed": result.killed,
            "saved": result.saved,
            "checked": result.checked,
            "checked_role": result.checked_role
        }
    return {"killed": None, "saved": None, "checked": None, "checked_role": None}


@rooms_router.post("/{room_id}/ai-turn")
async def trigger_ai_turn(
    room_id: int,
    db: Session = Depends(get_db)
):
    try:
        room = db.query(RoomDB).filter(RoomDB.id == room_id).first()
        if not room:
            raise HTTPException(status_code=404, detail="Room not found")
        
        db.refresh(room)
        db.refresh(room, ['players'])
        
        print(f"=== AI turn: room {room_id}, phase: {room.phase} ===")
        
        messages = db.query(MessageDB).filter(
            MessageDB.room_id == room_id
        ).order_by(MessageDB.id.desc()).limit(30).all()
        
        recent_messages = [
            {"player_id": m.player_id, "player_name": m.player_name, "text": m.text}
            for m in reversed(messages)
        ]
        
        game_state = {
            "day_number": room.day_number,
            "phase": room.phase,
            "players": [
                {
                    "id": str(p.id),
                    "name": p.name,
                    "role": p.role,
                    "is_alive": p.is_alive,
                    "is_ai": p.is_ai
                }
                for p in room.players
            ]
        }
        
        alive_players = [p for p in room.players if p.is_alive]
        
        bot_messages = []
        
        for player in alive_players:
            if not player.is_ai or not player.is_alive:
                continue
            
            ai_player = get_or_create_ai_player(room_id, player)
            ai_player.update_context(recent_messages, game_state)
            
            if room.phase == "day":
                text = await yandex_ai.generate_response(ai_player, game_state)
                if not text:
                    text = random.choice([
                        f"Я доверяю {random.choice(alive_players).name if len(alive_players) > 1 else 'себе'}",
                        f"Думаю, нужно голосовать против {random.choice(alive_players).name}",
                        "Давайте обсудим кандидатуры",
                        f"Я не мафия, поверьте мне!",
                    ])
            else:
                continue
            
            msg = MessageDB(
                room_id=room_id,
                player_id=player.id,
                player_name=player.name,
                text=text,
                is_ai=True
            )
            db.add(msg)
            db.commit()
            db.refresh(msg)
            
            await broadcast(room_id, "message", {
                "message": {
                    "id": msg.id,
                    "player_id": msg.player_id,
                    "player_name": msg.player_name,
                    "text": msg.text,
                    "is_ai": msg.is_ai,
                    "timestamp": msg.timestamp
                }
            })
            
            bot_messages.append(f"{player.name} ({player.role}): {text}")
            await asyncio.sleep(0.8)
        
        print(f"=== Bot messages: {bot_messages} ===")
        
        return {"status": "ok", "messages": bot_messages, "count": len(bot_messages)}
        
    except Exception as e:
        print(f"AI-turn error: {e}")
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e))
        raise HTTPException(status_code=500, detail=str(e))
    
    return {"status": "ok"}


@rooms_router.post("/{room_id}/phase", response_model=RoomDetail)
async def toggle_phase(
    room_id: int,
    db: Session = Depends(get_db)
):
    room = db.query(RoomDB).filter(RoomDB.id == room_id).first()
    if not room:
        raise HTTPException(status_code=404, detail="Room not found")
    
    current_phase = room.phase
    print(f"=== Toggle phase: room {room_id}, current: {current_phase} ===")
    
    if current_phase == "lobby":
        room.phase = "day"
        db.commit()
        phase_msg = MessageDB(
            room_id=room_id,
            player_id=0,
            player_name="Game",
            text="🎮 Игра началась! День 1. Обсуждайте и голосуйте!",
            is_ai=True
        )
        db.add(phase_msg)
        db.commit()
        
    elif current_phase == "day":
        room.phase = "night"
        room.day_number = 1
        db.commit()
        
        alive_players = [p for p in room.players if p.is_alive]
        mafia_members = [p for p in alive_players if p.role == "mafia"]
        
        phase_msg = MessageDB(
            room_id=room_id,
            player_id=0,
            player_name="Game",
            text="🌙 Наступает ночь! Мафия выбирает жертву...",
            is_ai=True
        )
        db.add(phase_msg)
        db.commit()
        
        if mafia_members:
            villagers = [p for p in alive_players if p.role != "mafia"]
            if villagers:
                target = random.choice(villagers)
                killed_player = next((p for p in room.players if p.id == target.id), None)
                if killed_player:
                    killed_player.is_alive = False
                
                saved = random.choice(alive_players)
                if saved.id == target.id:
                    phase_msg2 = MessageDB(
                        room_id=room_id,
                        player_id=0,
                        player_name="Game",
                        text=f"💀 Ночь прошла! {target.name} был убит, но врач его спас!",
                        is_ai=True
                    )
                else:
                    phase_msg2 = MessageDB(
                        room_id=room_id,
                        player_id=0,
                        player_name="Game",
                        text=f"💀 Ночь прошла! {target.name} был убит мафией!",
                        is_ai=True
                    )
                db.add(phase_msg2)
        
        db.commit()
        
    elif current_phase == "night":
        room.phase = "day"
        room.day_number += 1
        db.commit()
        
        votes = db.query(VoteDB).filter(
            VoteDB.room_id == room_id,
            VoteDB.day_number == room.day_number
        ).all()
        
        if not votes:
            for player in room.players:
                if player.is_alive and player.id != 0:
                    targets = [p for p in room.players if p.is_alive and p.id != player.id]
                    if targets:
                        vote_target = random.choice(targets)
                        vote = VoteDB(
                            room_id=room_id,
                            player_id=player.id,
                            target_id=vote_target.id,
                            day_number=room.day_number
                        )
                        db.add(vote)
            
            db.commit()
            votes = db.query(VoteDB).filter(
                VoteDB.room_id == room_id,
                VoteDB.day_number == room.day_number
            ).all()
        
        alive_players = [p for p in room.players if p.is_alive]
        
        phase_msg = MessageDB(
            room_id=room_id,
            player_id=0,
            player_name="Game",
            text=f"☀️ Наступает день {room.day_number}! Подсчет голосов...",
            is_ai=True
        )
        db.add(phase_msg)
        db.commit()
        
        vote_counts = {}
        for vote in votes:
            vote_counts[vote.target_id] = vote_counts.get(vote.target_id, 0) + 1
        
        if vote_counts:
            max_votes = max(vote_counts.values())
            voted_out_ids = [pid for pid, cnt in vote_counts.items() if cnt == max_votes and max_votes > 0]
            
            if len(voted_out_ids) == 1:
                victim_id = voted_out_ids[0]
                for player in room.players:
                    if player.id == victim_id:
                        player.is_alive = False
                        msg = f"🚫 {player.name} проголосовали! Роль: {player.role}"
                        phase_msg2 = MessageDB(
                            room_id=room_id,
                            player_id=0,
                            player_name="Game",
                            text=msg,
                            is_ai=True
                        )
                        db.add(phase_msg2)
            else:
                phase_msg2 = MessageDB(
                    room_id=room_id,
                    player_id=0,
                    player_name="Game",
                    text="🤷 Никто не получил большинство голосов!",
                    is_ai=True
                )
                db.add(phase_msg2)
        
        db.commit()
        
        alive_after = [p for p in room.players if p.is_alive]
        mafia_alive = [p for p in alive_after if p.role == "mafia"]
        villagers_alive = [p for p in alive_after if p.role != "mafia"]
        
        if not mafia_alive:
            room.phase = "game_over"
            phase_msg3 = MessageDB(
                room_id=room_id,
                player_id=0,
                player_name="Game",
                text="🎉 ПОБЕДА МИРНЫХ! Мафия уничтожена!",
                is_ai=True
            )
            db.add(phase_msg3)
            db.commit()
        elif len(mafia_alive) >= len(villagers_alive):
            room.phase = "game_over"
            phase_msg3 = MessageDB(
                room_id=room_id,
                player_id=0,
                player_name="Game",
                text="💀 ПОБЕДА МАФИИ! Мирные проиграли!",
                is_ai=True
            )
            db.add(phase_msg3)
            db.commit()
    
    updated_room = db.query(RoomDB).filter(RoomDB.id == room_id).first()
    db.refresh(updated_room)
    
    return RoomDetail.model_validate(updated_room)


@rooms_router.websocket("/ws/rooms/{room_id}")
async def websocket_endpoint(websocket: WebSocket, room_id: int):
    await websocket.accept()
    
    if room_id not in active_connections:
        active_connections[room_id] = []
    active_connections[room_id].append(websocket)
    
    try:
        while True:
            data = await websocket.receive_text()
            import json
            try:
                message = json.loads(data)
                event_type = message.get("type")
                
                if event_type == "ping":
                    await websocket.send_json({"event": "pong"})
                elif event_type == "message":
                    from database import SessionLocal
                    db = SessionLocal()
                    try:
                        msg = game_engine.add_message(db, room_id, message["playerId"], message["text"])
                        if msg:
                            await broadcast(room_id, "message", {
                                "message": MessageResponse.model_validate(msg).model_dump()
                            })
                    finally:
                        db.close()
                elif event_type == "vote":
                    from database import SessionLocal
                    db = SessionLocal()
                    try:
                        vote_obj = game_engine.vote(db, room_id, message["playerId"], message["targetId"])
                    finally:
                        db.close()
            except (json.JSONDecodeError, KeyError):
                pass
    except WebSocketDisconnect:
        if room_id in active_connections:
            active_connections[room_id].remove(websocket)


router.include_router(auth_router)
router.include_router(rooms_router)


from datetime import datetime, timedelta